package com.yemage.mvc;

/**
 * @author yemage
 */
public enum ResponseType {
    TEXT,VIEW;
}
