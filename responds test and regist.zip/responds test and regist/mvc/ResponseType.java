package com.yemage.mvc;


public enum ResponseType {
    TEXT,VIEW;
}
